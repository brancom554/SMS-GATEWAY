package smsc;


import java.lang.reflect.Method;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import org.json.JSONException;
import org.json.JSONObject;
import toolkit.GSMConnect;
import toolkit.PortTest;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marius-GANHOUEGNON
 */

@Path("SMSC")
public class SMSUc {
    
    @POST
    @Path("/post")
    @Produces("application/json")
    public String ucSMS(@QueryParam("action") String action,  @QueryParam("params") JSONObject params) throws JSONException,  Exception{
        JSONObject result = new JSONObject();
        if(this.verifierMethode(SMSUc.class, action)){
            switch (action) {
                case "sendSMS":
                   // return this.sendSMS(params.getString("idUtilisateur"),params.getString("numeroUtilisateur"),params.getString("status"),params.getString("codeActivation"),params.getString("descriptionCompte"),params.getString("login"),params.getString("motDePasse"),params.getBoolean("recupMdp"), context);
                 return this.sendSMS(params.getString("to"),params.getString("message"),params.getString("sender"));

                 case "hello": 
                    return this.hello();
                 default:
                     System.out.println("Erreur");
            }
        }else{
            result.put("codeTraitement", 1001);
            result.put("description", "methode inexistante");
            return result.toString();
        }
        
        return "{}";
    }
    
    @GET
    @Path("/get")
    @Produces("application/json")
    public String ucSMS_Get(@QueryParam("action") String action,  @QueryParam("params") JSONObject params) throws JSONException,  Exception{
        JSONObject result = new JSONObject();
        if(this.verifierMethode(SMSUc.class, action)){
            switch (action) {
                case "sendSMS":
                   // return this.sendSMS(params.getString("idUtilisateur"),params.getString("numeroUtilisateur"),params.getString("status"),params.getString("codeActivation"),params.getString("descriptionCompte"),params.getString("login"),params.getString("motDePasse"),params.getBoolean("recupMdp"), context);
                 return this.sendSMS(params.getString("to"),params.getString("message"),params.getString("sender"));

                 case "hello": 
                    return this.hello();
                 default:
                     System.out.println("Erreur");
            }
        }else{
            result.put("codeTraitement", 1001);
            result.put("description", "methode inexistante");
            return result.toString();
        }
        
        return "{}";
    }
    
    
    private Boolean verifierMethode(Class clazz, String methode) throws NoSuchMethodException {
        StringBuilder sb = new StringBuilder();

        for (Method method : clazz.getDeclaredMethods()) {
            if (method.getName().equals(methode)) {
                sb.append("Method ").append(methode).append(" exists.");
                System.out.println(sb.toString());
                return true;
            } 
        }
        sb.append("Method ").append(methode).append(" not exists.");
        System.out.println(sb.toString());
        return false;
   
    }
    
            
    /*@POST
    @Path("/rechercherutilisateur")
    @Produces("application/json")
    private String ucRechercherUtilisateur (@PathParam("action") String action, @PathParam("listeCritere") JSONArray listeCritere, @PathParam("scenarioChargement") JSONArray scenarioChargement, @PathParam("context") Context context) throws JSONException{
        return null;
    }*/
            
   

            
    private String authentifierApp (String login, String mdp, Context context){
        //login = Md5.encode(login);
       
        
        
        return "";
    }

   private String sendSMS (String numero, String message,String sender) throws JSONException{
        //login = Md5.encode(login);
        int statutPort;String statut="";
       JSONObject result=new JSONObject();
      // GSMConnect
     
      
     // if(statutPort == 1){
      GSMConnect gsm = new GSMConnect("COM4");
       if (gsm.init()) {
         try {
             System.out.println("premiere chose:"+gsm.getClass().toGenericString());
             System.out.println("Initialization Success");
           gsm.connect();
           
           Thread.sleep(5000);
           gsm.checkStatus();
           Thread.sleep(5000);

           gsm.sendMessage(numero, message);
           //gsm.infoCredit();

          Thread.sleep(1000);
//System.out.println("voici le numero :"+numero);
           gsm.hangup();
           
           //Thread.sleep(1000);
           gsm.closePort();
           
           gsm.outCommand();
          
          // System.exit(1);
          statut = "SMS transmis";

         } catch (Exception e) {
           e.printStackTrace();
         }
      
      //fin GSMConnect
       //result.put("statut", statut);
       //result.put("codeTraitement", 0);
        
        
        
       
    }
     // }
      
      result.put("statut", statut);
       result.put("codeTraitement", 0);
    return result.toString();
   }


//donner la liste des méthodes
    private String hello() throws JSONException{
        JSONObject result=new JSONObject();
    String methode="sendSMS\n"+
                   
                     
                     " methode :hello \n"; 
    
     result.put("statut", "Méthodes Exposées :"+methode);
     result.put("codeTraitement", 0);
       return result.toString();
    }
                    
    
    
  
}
